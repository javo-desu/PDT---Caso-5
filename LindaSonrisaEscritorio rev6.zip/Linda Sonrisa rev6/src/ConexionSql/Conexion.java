/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ConexionSql;

import java.sql.*;

/**
 *
 * @author JAVO-KUN
 */
public class Conexion {

    private Connection conn;

    public void CrearBD() {
        this.CrearConexion();
    }

    private void CrearConexion() {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException e) {
            System.out.println("no se ha encontrado la clase oracle.jdbc.driver.OracleDriver");
        }
        try {
            conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "lindas", "123");
        } catch (Exception e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }

    public Statement createStatement() {
        Statement st = null;
        if (this.conn == null) {
            this.CrearConexion();
        }
        try {
            st = this.conn.createStatement();
        } catch (Exception e) {
            System.out.println("ERROr: " + e.getMessage());
        }
        return st;
    }

    public Connection abrirConexion() {
        if (this.conn == null) {
            this.CrearConexion();
        } else {
            try {
                if (this.conn.isClosed()) {
                    this.CrearConexion();
                }
            } catch (Exception e) {
                System.out.println("ERROR: " + e.getMessage());
            }

        }
        return this.conn;
    }

    public void ejecutarSQL(String SqlComm) {
        Statement st = this.createStatement();
        try {
            st.execute(SqlComm);
        } catch (Exception e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }

    public ResultSet executeQuery(String SqlComm) {

        Statement st = this.createStatement();
        ResultSet rs = null;

        try {
            rs = st.executeQuery(SqlComm);
        } catch (Exception e) {
            System.out.println("ERROR: " + e.getMessage());
        }
        return rs;
    }

    public ResultSet ejecutarQuery(String SqlComm) {
        Statement st = null;
        ResultSet rs = null;
        try {
            st = this.conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            rs = st.executeQuery(SqlComm);
        } catch (Exception e) {
            System.out.println("ERROR: " + e.getMessage());

        }
        return rs;
    }

    public void cerracConexion() {
        if (this.conn != null) {
            try {
                this.conn.close();
            } catch (Exception e) {
                System.out.println("ERROR: " + e.getMessage());
            }
        }

    }
}
