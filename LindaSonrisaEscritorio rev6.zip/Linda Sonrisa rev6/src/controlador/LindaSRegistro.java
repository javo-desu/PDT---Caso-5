/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;
import java.sql.Connection;
import modelo.*;
import ConexionSql.*;

/**
 *
 * @author JAVO-KUN
 */
public class LindaSRegistro {
//    public Empleado buscarEmpleado(Empleado empleado){
//        Empleado Empleado = null;
//        try {
//              Connection conexion = Conexion.getConexion();
//              
//              
//              return true;
//        } catch (Exception e) {
//            return false;
//        }
//        
//    }
}
